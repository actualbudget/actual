
This is a YNAB Budget Folder, meant to be opened with "You Need a Budget". 
This folder and all folders/files beneath it are required in order to use it.
To copy this budget to another folder, copy the entire folder that contains this file.
Do not just copy individual files/folders, or it probably won't work.


Technical Note for Windows users:
If you're reading this file, you've already demonstrated that you're used to poking around
inside folders, so we wanted to explain something you might be curious about:
YNAB for Windows hides all of the folders in here. We're not trying to hide stuff from you, but
if there are visible sub-folders, when you use YNAB to browse to open a YNAB budget folder, 
the browse dialog would let you expand this folder, which makes it difficult for some customers 
to tell which folder they should select. By hiding the folder we make this folder look more 
like a file.